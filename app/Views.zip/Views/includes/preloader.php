<div id="preloader">
        <div class="loader"></div>
</div>
<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<title><?php echo esc($title) ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
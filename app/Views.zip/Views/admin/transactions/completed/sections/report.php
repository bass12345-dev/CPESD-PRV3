 <div id="generate_pmas_report_section" hidden="true">
                                        <div class="row mt-2">

                                            <div class="col-md-12"> 
                                                <button class="btn  mb-3 mt-2 btn-danger pull-right" id="close_pmas_report_section" ><i class="ti-close "></i></button>   
                                               
                                             </div>
                                            
                                        </div>
                                        <div class="row">
                                            <div class="col-12 mt-2">
                                                <table id="completed_transactions_table" class="text-center stripe ">
                                                   <thead class="bg-light text-capitalize" >
                                                       <tr>
                                                           <th>PMAS NO</th>
                                                           <th>Date & Time Filed</th>
                                                           <th>Type of Activity</th>
                                                           <th>CSO</th>
                                                           <th>Person Responsible</th>
                                                            <th>Action</th>
                                                       </tr>
                                                   </thead> 

                                                  <!--   <tfoot>
                                                            <tr>
                                                                <th>Total Volume of Business:</th>
                                                                <th></th>

                                                                <th  >Total Cash Position:</th>
                                                                <th></th>

                                                            </tr>

                                                             
                                                        </tfoot> -->

                                                                    
                                               </table>   
                                            </div>
                                            <div id="total_section" hidden>
                                            <div class="col-12"><h5>Total Volume of Business : <span class="all_total_volume_of_business"></span></h5> </div>
                                            <div class="col-12"><h5>Total Cash Position :   <span class="all_total_cash_position"></span></h5></div>
                                            </div>
                                        </div>
                                    </div>
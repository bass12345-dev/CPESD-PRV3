<div class="row">
   <div class="col-12 mt-5">
      <div class="card" style="border: 1px solid;">
         <div class="card-body">
            <div class="row">
               <div class="col-md-12">
                 
                                          
                  <div class="data-tables">
                     <table id="per_barangay_table" style="width:100%" class="text-center">
                        <thead class="bg-light text-capitalize">
                           <tr>
                              <th>Barangay</th>
                              <th>Active</th>
                              <th>Inactive</th>
                           </tr>
                        </thead>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
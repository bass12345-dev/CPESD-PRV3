<div class="col-md-6">
   <div class="card">
      <h4 class="header-title">Add Responsibilty Center</h4>
      <form id="add_responsibility_center_form">
         <div class="form-group">
            <div class="col-12">Responsibilty Center Code<span class="text-danger">*</span></div>
            <input  type="number" class="form-control input" id="res_code" name="res_code"  placeholder="" required>      
         </div>
         <div class="form-group">
            <div class="col-12">Responsibilty Center Name<span class="text-danger">*</span></div>
            <input type="text" class="form-control input" id="center_name" name="center_name" placeholder="" required>
         </div>
         <button  type="submit" class="btn mt-1 pr-4 pl-4 btn-add-center sub-button"> Submit</button>
         <div class="alert"></div>
      </form>
   </div>
</div>
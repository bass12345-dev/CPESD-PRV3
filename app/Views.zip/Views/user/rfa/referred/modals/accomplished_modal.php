<div class="modal fade" id="accomplished_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static" data-keyboard="false">
   <div class="modal-dialog modal-dialog-centered "  role="document">
      <div class="modal-content">
         <div class="modal-header">

            &nbsp;
            <h5 class="modal-title type_of_training_title" ></h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <div class="modal-body">
            <div class="row">
               
               <div class="col-md-12">
                  <div class="card">
                     
                     <form id="action_to_be_taken_form">
                        <input  type="hidden" class="form-control"  name="rfa_id"  placeholder="" required>
                        

                        <div class="form-group">
                           <div class="col-12">Action To Be Taken</div>
                              <textarea class="form-control" id="action_to_be_taken" name="action_to_be_taken"></textarea>
                          
                                
                        </div>
                        <button  type="submit" class="btn sub-button mt-1 pr-4 pl-4 btn-refer pull-right">Accomplished</button>
                        <div class="alert-add-under-activity"></div>
                        <!--  -->
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<ul  class="nav nav-pills nav-tabs ">
			<li class=" nav-item">
        <a  href="#1a" data-toggle="tab"  class="nav-link active" >CSO Information</a>
			</li>
			
			<li class="nav-item"><a href="#2a"  class="nav-link" data-toggle="tab">CSO Officers</a>
			</li>
			<!-- <li class="nav-item"><a href="#3a"  class="nav-link" data-toggle="tab">CSO Completed Transactions</a>
			</li> -->
			
		</ul>
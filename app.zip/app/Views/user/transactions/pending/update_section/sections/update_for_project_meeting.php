<div class="for_project_meeting" hidden>
	<h3>For Project Meeting</h3>	
	<h4>Attendance</h4>
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6">
			<div class="form-group">
				<div class="col-12">Present</div>
				<input type="number" class="form-control input" name="update_meeting_present" placeholder="">
				<div class="wizard-form-error"></div>
			</div>
		</div>
		<div class="col-lg-6 col-md-6 col-sm-6">
			<div class="form-group">
				<div class="col-12">Absent</div>
				<input type="number" class="form-control input" name="update_meeting_absent" placeholder="">
				<div class="wizard-form-error"></div>
			</div>
		</div>
	</div>
</div>
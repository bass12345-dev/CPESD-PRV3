<div class="col-md-6 ">
   <div class="data-tables">
      <table class="tablesaw table-bordered table-hover table" >
         <tr>
            <td colspan = "2">
               <a  href    = "javascript:;" class = "mt-2  mb-2 btn sub-button text-center  btn-rounded btn-md btn-block"><i class = "fa fa-user" aria-hidden = "true"></i>RFA Information</a>
           
            </td>
         </tr>
         <tr>
            <td >Reference No.</td>
            <td class="reference_no"></td>
         </tr>
         <tr>
            <td >Name of Client</td>
            <td class="name_of_client"></td>
         </tr>
         <tr>
            <td >Type Of Request</td>
            <td class="type_of_request"></td>
         </tr>
         <tr>
            <td>Type Of Transaction</td>
            <td class="type_of_transaction"></td>
         </tr>
         <tr>
            <td >Date & Time Filed</td>
            <td class="date_and_time"></td>
         </tr>
      </table>


   </div>
</div>